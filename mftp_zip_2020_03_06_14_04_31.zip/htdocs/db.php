<?php
$con = mysqli_connect("sql102.epizy.com","epiz_25163006","rutvik7284","epiz_25163006_rut") or die(mysql_error());

?>