<?php

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>Rutvik Dholakiya</title>
    <link rel="icon" href="images/favicon.ico">


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700,900" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/fancybox.min.css">

    <link rel="stylesheet" href="css/style.css">
    

    <link rel="stylesheet" 
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" 
    crossorigin="anonymous">

<script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
    integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
    crossorigin="anonymous"></script>
<script 
    src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" 
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
<script 
    src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" 
    crossorigin="anonymous"></script>
    
<script src="https://www.sowecms.com/demos/statics/prism.js"></script>


<style>

    .bg-primary-2 {
        background-color: #3779B3;
    }

   

    .text-underline {
        text-decoration: underline;
    }

    .text-bold {
        font-weight: 700;
    }

    .text-italic {
        font-style: italic;
    }

    .text-small {
        font-size: 0.8em;
    }

    .flex-grow-1 {
        flex-grow: 1;
    }

    #btn-top {
        position: fixed;
        z-index: 999;
        bottom: 1em;
        top: auto;
        left: auto;
        right: 1em;
        margin-left: -1.9rem;
        opacity: .66;
        display: none;
    }

    .instagram_feed {
        overflow:hidden;
    }

    #jsonHere {
        max-height: 60vh;
        overflow: auto;
    }
</style>



  </head>
  <body>
    

  <div class="site-wrap">

  <div class="site-mobile-menu">
    <div class="site-mobile-menu-header">
      <div class="site-mobile-menu-close mt-3">
        <span class="icon-close2 js-menu-toggle"></span>
      </div>
    </div>
    <div class="site-mobile-menu-body"></div>
  </div>

  <header class="header-bar d-flex d-lg-block align-items-center" data-aos="fade-left">
    <div class="site-logo">
      <a href="index.html">RUTVIK <br>DHOLAKIYA</a>
    </div>
    
    <div class="d-inline-block d-xl-none ml-md-0 ml-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

    <div class="main-menu">
      <ul class="js-clone-nav">
        <li class="active"><a href="index.html">Home</a></li>
        <li><a href="photos.html">Friendzone</a></li>
        <li><a href="bio.html">About Me</a></li>
        <li><a href="blog.html">Blog</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
      <ul class="social js-clone-nav">
        <li><a href="https://www.facebook.com/Mr.Rutvik.Dholakiya.42"><span class="icon-facebook"></span></a></li>
        <li><a href="https://www.snapchat.com/add/royal_ruts"><span class="icon-snapchat"></span></a></li>
        <li><a href="https://www.instagram.com/royal_rut.s_official/"><span class="icon-instagram"></span></a></li>
      </ul>
    </div>
  </header> 


  <main class="main-content">
    <div class="container-fluid photos">
      
        <br>
        <br>
        <div id="instagram-feed1" class="instagram_feed"></div>
        <div class="section_code py-3"></div>
        

        <script src="jquery.instagramFeed.min.js"></script>
        <script>
            (function($){
                $(window).on('load', function(){
                    $.instagramFeed({
                        'username': 'royal_rut.s_official',
                        'container': "#instagram-feed1",
                        'display_profile': true,
                        'display_biography': true,
                        'display_gallery': true,
                        'callback': null,
                        'styling': true,
                        'items': 100,
                        'items_per_row': 2,
                        'margin': 1
                    }); 
                    
                   
                    
                    // Show back to top button if distance from top > 0
                    $(window).scroll(function(){ 
                        var viewportTop = $(window).scrollTop() + $(window).height();
                 
                        if($(window).scrollTop() > 10){
                            $('#btn-top').addClass('d-block');
                            $('#btn-top').removeClass('d-none');
                        }else{
                            $('#btn-top').addClass('d-none');
                            $('#btn-top').removeClass('d-block');
                        }
                    });
    
                });
            })(jQuery);
        </script>
          

        
      
      
      </div>
      <div class="row justify-content-center">
        <div class="col-md-12 text-center py-5">
          <p>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
         &copy;<script>document.write(new Date().getFullYear());</script> | Made <i class="icon-heart" aria-hidden="true"></i> by <a target="_blank" >Rutvik Dholakiya</a>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      </p>
        </div>
      </div>
    </div>
  </main>

</div> <!-- .site-wrap -->


  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/jquery.fancybox.min.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>